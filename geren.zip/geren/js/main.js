//首页字体逐字出现
var paper = "Hello! 这是我2019的个人网页 . . .";
         var count = 1;
        function oneByOne()
         {
            var screen = paper.substr(0, count);
            loopText.innerHTML = screen;   
            count++;
           if (count > paper.length)
                 return;
           setTimeout(oneByOne, 200);
       }
        onload = oneByOne;

//首页弹框
var box = document.getElementById('box');
var btn = document.getElementById('btn');
var CloseHide = document.getElementById('Closehide');
btn.onclick = function () {
    box.style.display = "block";
}
Closehide.onclick = function(){
    box.style.display = "none";
}
